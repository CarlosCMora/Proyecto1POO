package proyectoadminpoo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

public class Asignatura {
    static int total_asignaturas = 0;
    private String clave;
    private String nombre;
    private int creditos;
    HashSet<Libro>hLibros= new HashSet<>();
    
    public Asignatura(){
        total_asignaturas++;
    }

    public Asignatura(String clave, String nombre, int creditos){
        setClave(clave);
        setCreditos(creditos);
        setNombre(nombre);
        total_asignaturas++;

    }

    public String getClave() {
        return clave;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCreditos() {
        return creditos;
    }
    
    public HashSet<Libro> getLibros(){
        return hLibros;
    }

    public boolean setClave(String clave) {
        if(clave.length() != 4){
            System.out.println("La clave no es valida, intenta de nuevo");
            return false;
        }
        this.clave = clave;
        return true;
    }

    public boolean setNombre(String nombre) {
        if (nombre.length()>20 || nombre.length()<2) {
            System.out.println("El nombre de la asignatura no es valido, intenta de nuevo");
            return false;
        }
        this.nombre = nombre;
        return true;
    }

    public boolean setCreditos(int creditos) {
        if (creditos<2 || creditos>10) {
            System.out.println("La cantidad de creditos no es valida, intenta de nuevo");
            return false;
        }
        this.creditos = creditos;
        return true;
    }
    
    public void setLibros(HashSet<Libro> lista){
        hLibros = lista;
    }
    

    public static Asignatura crearAsignatura() {
        Asignatura a1 = new Asignatura();
        Scanner sc = new Scanner(System.in);
        int i;
        String s;
        do {
            System.out.println("Ingresa el nombre de la asignautra");
            s = sc.nextLine();
        } while (!a1.setNombre(s));
        
        do {
            System.out.println("Ingresa la clave de la asignautra");
            s = sc.nextLine();
        } while (!a1.setClave(s));

        do {
            System.out.println("Ingresa los creditos de la asignautra");
            i = Integer.parseInt(sc.nextLine());
        } while (!a1.setCreditos(i));
        
        return a1;
    }
    public void printAsignatura(boolean i) {
        System.out.println("Nombre de la asignatura: "+getNombre());
        System.out.println("Clave: "+getClave());
        if (i) {
            System.out.println("Creditos: "+getCreditos());
            printLibros();
        }
        
        System.out.println();
    }

    public static void printAsignatura(HashMap<String, Asignatura> hash_asignaturas) {
        for ( Map.Entry<String, Asignatura> entry : hash_asignaturas.entrySet()) {
            entry.getValue().printAsignatura(true);
        }
    }


    public static void mostrarAsignatura(HashMap<String, Asignatura> hash_asignaturas) {
        for ( Map.Entry<String, Asignatura> entry : hash_asignaturas.entrySet()) {
            entry.getValue().printAsignatura(false);
        }
    }

    public void agregarLibro() {
        Libro libro = new Libro();
        String nombre, isbn;
        int i;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Ingresa el nombre del libro");
            nombre = sc.nextLine();
        } while (!libro.setNombre(nombre));

        do {
            System.out.println("Ingresa el numero de paginas");
            i = Integer.parseInt(sc.nextLine());
        } while (!libro.setPaginas(i));

        do {
            System.out.println("Ingresa el numero de edicion");
            i = Integer.parseInt(sc.nextLine());
        } while (!libro.setEdicion(i));

        do {
            System.out.println("Ingresa el codigo del ISBN ||Recuerda que tiene solo 13 digitos");
            isbn = sc.nextLine();
        } while (!libro.setISBN(isbn));

        hLibros.add(libro);

    }

    public void printLibros() {
        for (Libro libro : hLibros) {
            libro.print();
        }
    }

}
