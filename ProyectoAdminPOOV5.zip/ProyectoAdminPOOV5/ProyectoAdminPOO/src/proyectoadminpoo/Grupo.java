package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Grupo {
    public static int total_grupos = 0;
    private int num_grupo;
    private String salon;
    private Profesor profesor;
    private Asignatura asignatura;
    private int conteo_alumnos_para_grupo = 0;
    private ArrayList <Alumno>listAlumnos = new ArrayList<Alumno>();
    
    public Grupo(int num, String saln, Profesor profe, Asignatura asig){
        num_grupo = num;
        salon = saln;
        profesor = profe;
        asignatura = asig;
        total_grupos++;
    }

    public int getNum_grupo() {
        return num_grupo;
    }

    public String getSalon() {
        return salon;
    }

    public Profesor getProfesor() {
        return profesor;
    }
    
    public Asignatura getAsignatura(){
        return asignatura;
    }

    public ArrayList <Alumno> getListAlumnos() {
        return listAlumnos;
    }

    public void setNum_grupo(int num_grupo) {
        this.num_grupo = num_grupo;
    }

    public void setSalon(String salon) {
        this.salon = salon;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }
    
    public void setAsignatura(Asignatura asignatura){
        this.asignatura = asignatura;
    }

    public void setListAlumnos(ArrayList <Alumno> listAlumnos) {
        this.listAlumnos = listAlumnos;
    }
    
    //static public Grupo agregarGrupo(Profesor profe_act, Asignatura asig_act){
    static public Grupo agregarGrupo(Profesor profe_act, Asignatura asig){
        //Solicita los datos necesarios para llamar al constructor de la clase Grupo y asi regresar el objeto correspondiente
        String saln;
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el salon que le corresponde al grupo: ");
        saln = sc.nextLine();
        
        Grupo g_act= new Grupo(total_grupos+1, saln, profe_act, asig);
        return g_act;
    }
    
    @Override
    public String toString(){
        return asignatura.getNombre()+" "+num_grupo+" "+profesor.getNombre()+" "+profesor.getApellido();
    }
    
    static public void listarGrupos(ArrayList<Grupo> lista){
        int i = 1;
        for (Grupo g_act : lista){
            System.out.println(i+". "+g_act.toString());
            i++;
        }
    }
    
    public void inscribirAlumno(Alumno alu){
        listAlumnos.add(alu);
        conteo_alumnos_para_grupo++;
        alu.asignarLibros(asignatura.getLibros());
        alu.setConteo_asignaturas(alu.getConteo_asignaturas()+1);
    }
    
    public static void listarGruposAlumno(ArrayList<Grupo> lista) {
        int i = 1;
        for (Grupo g_act : lista){
            System.out.println(i+". "+g_act.toString());
            System.out.println("Alumnos");
            Alumno.listarAlumnos(g_act.listAlumnos);
            i++;
        }
    }
}
