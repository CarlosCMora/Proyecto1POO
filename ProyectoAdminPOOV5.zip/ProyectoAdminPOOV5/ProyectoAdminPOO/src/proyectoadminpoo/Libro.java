package proyectoadminpoo;

public class Libro {
    private String nombre;
    private int edicion;
    private int paginas;
    String ISBN;
    
    public Libro(){

    }
    public Libro(String nom, int edit, int pags, String isbn){
        nombre = nom;
        edicion = edit;
        paginas = pags;
        ISBN = isbn;
    }
    public boolean setISBN(String iSBN) {
        if(iSBN.length()== 13){
            ISBN = iSBN;
            return true;
        }else{
            return false;
        }
        
    }
    public String getISBN() {
        return ISBN;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            return false;
        }
        
    }

    public int getEdicion() {
        return edicion;
    }

    public boolean setEdicion(int edicion) {
        if(0<edicion&&edicion<100){
            this.edicion = edicion;
            return true;
        }else{
            return false;
        } 
    }

    public int getPaginas() {
        return paginas;
    }

    public boolean setPaginas(int paginas) {
        if(0<paginas&&paginas<5001){
            this.paginas = paginas;
            return true;
        }else{
            return false;
        }
        
    }

    public void print() {
        System.out.println("El nombre del libro es: "+getNombre());
        System.out.println("El numero de paginas del libro es: "+getPaginas());
        System.out.println("El numero de edicion del libro es: "+getEdicion());
        System.out.println("El ISBN del libro es: "+getISBN());
    }


}
