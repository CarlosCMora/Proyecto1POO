package proyectoadminpoo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Alumno{
    static int total_alumnos = 0;
    private long numcuenta;
    private String nombre;
    private String apellido;
    private Domicilio domicilio;
    private HashSet<Libro> listalibros = new HashSet<>();
    private int conteo_asignaturas = 0;
    
    public Alumno(){
        total_alumnos++;
    }
    
    public Alumno(long numcuenta, String nombre, String apellido, Domicilio domicilio){
        total_alumnos++;
        this.numcuenta = (long)numcuenta;
        this.nombre = nombre;
        this.apellido = apellido;
        this.domicilio = domicilio;
    }

    public long getNumcuenta() {
        return numcuenta;
    }

    public boolean setNumcuenta(long numcuenta) {
        if(String.valueOf(numcuenta).length()==9){
            this.numcuenta = numcuenta;
            return true;
        }else{
            System.out.println("El numero de cuenta debe de tener 9 digitos. Intentalo de nuevo");
            return false;
        }    
    }

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            System.out.println("El nombre no cumple con la longuitud(3-24 caracteres). Intentalo de nuevo");
            return false;
        }
    }

    public String getApellido() {
        return apellido;
    }

    public boolean setApellido(String apellido) {
        if(2<apellido.length() && apellido.length()<30){
            this.apellido = apellido;
            return true;
        }else{
            System.out.println("Los apellidos no cumplen con la longuitud(3-24 caracteres). Intentalo de nuevo");
            return false;
        }
    }
    public void setDomicilio(Domicilio domicilio) {
        this.domicilio = domicilio;
    }
    
    public int getConteo_asignaturas(){
        return conteo_asignaturas;
    }
    
    public void setConteo_asignaturas(int aumento){
        //Solo se le tiene que terminar aumentando 1
        conteo_asignaturas = aumento;
    }
            
    static public Alumno agregarAlumno(){
        String nombre, apellido, delegacion, colonia, direccion;
        Alumno a1 = new Alumno();
        Domicilio domicilio_act = new Domicilio();
        long num_cuenta;

        System.out.println("Ingrese los datos del alumno "+(Alumno.total_alumnos+1));
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("Numero de cuenta: ");
            num_cuenta = Integer.parseInt(sc.nextLine());
        } while (!a1.setNumcuenta(num_cuenta));

        do {
            System.out.print("Nombre: ");
            nombre = sc.nextLine();
        } while (!a1.setNombre(nombre));
        
        do {
            System.out.print("Apellido: ");
            apellido = sc.nextLine();
        } while (!a1.setApellido(apellido));

        
        System.out.println("Ingrese la direccion del alumno con numero de cuenta "+num_cuenta);

        do {
            System.out.print("Delegacion: ");
            delegacion = sc.nextLine();
        } while (!domicilio_act.setDelegacion(delegacion));
        
        do {
            System.out.print("Colonia: ");
            colonia = sc.nextLine();
        } while (!domicilio_act.setColonia(colonia));

        do {
            System.out.print("Direccion: ");
            direccion = sc.nextLine();
        } while (!domicilio_act.setDireccion(direccion));
        a1.setDomicilio(domicilio_act);
        
        return a1;
    }
    
    public void mostrarAlumno(){
        System.out.println("Numero de cuenta: "+numcuenta);
        System.out.println("Nombre: "+nombre);
        System.out.println("Apellido: "+apellido);
        domicilio.mostrarDomicilio();
        System.out.println("Por el momento el alumno cuenta con "+listalibros.size()+" libros asignados\n");
        for( Libro l_act : listalibros){
            l_act.print();
        }
    }
    
    @Override
    public String toString(){
        //Regresa una String conteniendo los datos del objeto
        return nombre+" "+apellido+"\t\t"+numcuenta;
    }
    
    static void mostrarAlumnos(ArrayList<Alumno> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma desglosada
        //Con ayuda del metodo mostrarProfesor()
        for (Alumno alu_act : lista){
            alu_act.mostrarAlumno();
        }
        System.out.println();
    }
    
    static void listarAlumnos(ArrayList<Alumno> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma compacta y mostrando un indice al usuario
        //Usa el metodo toString()
        System.out.println("Nombre\t\t\tNumero de Cuenta");
        int i = 0;
        for (Alumno alu_act: lista){
            System.out.println((i+1)+". "+alu_act.toString());
            i++;
        }   
    }
    
    public void asignarLibros(HashSet<Libro> libros_asingatura){
        listalibros.addAll(libros_asingatura);
    }
    
}
