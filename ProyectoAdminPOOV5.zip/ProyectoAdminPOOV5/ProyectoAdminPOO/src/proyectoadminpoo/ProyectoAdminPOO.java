
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ProyectoAdminPOO{

    public static void main(String[] args) {
        ArrayList <Alumno> lista_alumnos = new ArrayList<>();
        ArrayList <Profesor> lista_profesores = new ArrayList<>();
        ArrayList <Grupo> lista_grupos = new ArrayList<>();
        HashMap<String, Asignatura> hash_asignaturas = new HashMap<>();
        //ArrayList<Integer> claves_asignaturas = new ArrayList<>(); 
        /*??? Aqui se guardan las claves respectivas de las asignaturas y se asigna la pareja (clave,Asignatura) y si requerimos 
        recorrer las Asignaturas o pedirle al usuario elegir una, iteramos sobre esta lista para que a su vez muestre el hashmap asignaturas ???? 
        
        */
        boolean a;
        String s, opasig;
        int op, op2, opprof, opalu, opgrupo;
        Scanner sc = new Scanner(System.in);
        
        lista_profesores.add(new Profesor(4565478, "Juan", "Perez Sanchez"));
        lista_profesores.add(new Profesor(4645789, "Edgar", "Hernandez Benitez"));
        lista_alumnos.add(new Alumno(45465497, "Luis", "Saez", new Domicilio("AO", "Olivar", "Calle 10")));
        lista_alumnos.add(new Alumno(99878798, "Julia", "Martinez", new Domicilio("BJ", "Madero", "Calle 20")));
        lista_alumnos.add(new Alumno(99878798, "Cesar", "Islas", new Domicilio("VC", "Cerro", "Calle 30")));
        hash_asignaturas.put("1323", new Asignatura("1323", "POO", 10));
        hash_asignaturas.get("1323").hLibros.add(new Libro("POO for Dummies", 2, 1201, "1234567890123"));
        hash_asignaturas.get("1323").hLibros.add(new Libro("Fundamentos de POO", 5, 400, "1234567890123"));
        hash_asignaturas.put("1317", new Asignatura("1317", "EDAII", 10));
        hash_asignaturas.get("1317").hLibros.add(new Libro("EDA for Dummies", 4, 1121, "1234567890123"));
        hash_asignaturas.get("1317").hLibros.add(new Libro("Algos de Ordenamiento", 7, 2785, "1234567890123"));
        lista_grupos.add(new Grupo(Grupo.total_grupos+1, "Q213", lista_profesores.get(0), hash_asignaturas.get("1323")));
        
        do{
            //Menu general
            
            System.out.println("Bienvenido al sistema de inscripcion\n1)Alumnos\n2)Profesores\n3)Servicio Escolar\n4)Grupos\n5)Salir");
            op = Integer.parseInt(sc.nextLine());
            switch (op){
                case 1:  
                    do {
                        //Menu para alumnos
                        
                        System.out.println("\t\tPortal del alumno\n1)Mostrar alumnos\n2)Agregar Alumno\n3)Inscribir a grupo a Alumno\n4)Regresar");
                        op2 = Integer.parseInt(sc.nextLine());
                        switch (op2) {
                            case 1:                                  
                                //Si existen alumnos en la lista, se muestran, en caso contrario se muestra un mensaje en pantalla
                                if(Alumno.total_alumnos != 0){
                                    Alumno.listarAlumnos(lista_alumnos);
                                    System.out.println("Elija al alumno del cual quiere ver sus datos en detalle");
                                    opalu = Integer.parseInt(sc.nextLine());

                                    while(!(0 <= opalu-1 && opalu-1 < Alumno.total_alumnos)){
                                        System.out.print("Elija un alumno por su indice en la lista: ");
                                        opalu = Integer.parseInt(sc.nextLine());
                                    }
                                    lista_alumnos.get(opalu-1).mostrarAlumno();
                                    enterParaContinuar();
                                }else{
                                    System.out.print("\nAun no hay alumnos registrados!!\n");
                                    enterParaContinuar();
                                }
                                break;

                            case 2:
                                //Permite al usuario agregar alumnos en la lista correspondiente
                                lista_alumnos.add(Alumno.agregarAlumno());
                                System.out.print("\nAlumno agregado correctamente\n");
                                enterParaContinuar();
                                break;
                            case 3:
                                if(Alumno.total_alumnos != 0 && Grupo.total_grupos !=0){
                                    do{
                                        Alumno.listarAlumnos(lista_alumnos);
                                        System.out.println("Elija por el indice mostrado al alumno al cual le desea asignar grupo");
                                        opalu = Integer.parseInt(sc.nextLine());
                                    }while(!(0 <= opalu-1 && opalu-1 < Alumno.total_alumnos));
                                    
                                    if(lista_alumnos.get(opalu-1).getConteo_asignaturas() >=3 ){
                                        System.out.println("El alumno ha alcanzado su maximo de 3 asignaturas");
                                        break;
                                    }

                                    do{
                                        Grupo.listarGrupos(lista_grupos);
                                        System.out.println("Elija un grupo por el indice mostrado en la lista: ");
                                        opgrupo = Integer.parseInt(sc.nextLine());
                                    }while(!(0 <= opgrupo-1 && opgrupo-1 < Grupo.total_grupos));
                                    
                                    if(lista_grupos.get(opgrupo-1).getListAlumnos().contains(lista_alumnos.get(opalu-1))){
                                        System.out.println("El alumno ya se encuentra inscrito en el grupo seleccionado");
                                        break;
                                    }
                                    
                                    lista_grupos.get(opgrupo-1).inscribirAlumno(lista_alumnos.get(opalu-1));

                                }else if(Alumno.total_alumnos == 0){
                                    System.out.print("\nAun no hay alumnos registrados!!\n");
                                    enterParaContinuar();
                                }else if(Grupo.total_grupos == 0){
                                    System.out.print("\nAun no hay grupos registrados!!\n");
                                    enterParaContinuar();
                                }
                                
                                break;

                            case 4:
                                System.out.println("Hasta pronto");
                                break;

                            default:
                                System.out.println("Ingresa una opcion valida");
                                break;
                        }
                    }while (op2!=4);
                    break;
                
                case 2:
                    //Menu para Profesores
                    
                    do {
                    System.out.println("\t\tPortal del profesor\n1)Mostrar profesores\n2)Registrar profesor\n3)Dar de alta grupo\n4)Darse de baja\n5)Regresar");
                    op2 = Integer.parseInt(sc.nextLine());
                    switch (op2) {
                        case 1:  
                            //Si existen profesores en la lista, se muestran, en caso contrario se muestra un mensaje en pantalla
                            if(Profesor.total_profesores != 0){
                                do{
                                    Profesor.listarProfesores(lista_profesores);
                                    System.out.println("Elija por su indice al profesor al cual del cual desea ver los datos a detalle: ");
                                    opprof = Integer.parseInt(sc.nextLine());
                                }while(!(0 <= opprof-1 && opprof-1 < Profesor.total_profesores));
                                
                                lista_profesores.get(opprof-1).mostrarProfesor();
                                enterParaContinuar();
                            }else{
                                System.out.print("\nAun no hay profesores registrados!!\n");
                                enterParaContinuar();
                            }
                            break;
                        case 2:
                            //Permite al usuario agregar profesores en la lista correspondiente
                            lista_profesores.add(Profesor.agregarProfesor());
                            System.out.print("\nProfesor agregado correctamente\n");
                            enterParaContinuar();
                            break;
                        case 3:
                            //Si existen profesores y asignaturas en sus listas correspondientes, se muestran y se le pide al usuario asignar un profesor y una asignatura al nuevo grupo 
                            //Si no hay ni profesores ni asignaturas, se muestan en pantalla los mensajes correspondientes
                            if(Profesor.total_profesores != 0 && Asignatura.total_asignaturas != 0){
                                do{
                                    Profesor.listarProfesores(lista_profesores);
                                    System.out.print("Elija por su indice al profesor al cual le desea asignar grupo: ");
                                    opprof = Integer.parseInt(sc.nextLine());
                                }while(!(0 <= opprof-1 && opprof-1 < Profesor.total_profesores));

                                do{
                                    Asignatura.mostrarAsignatura(hash_asignaturas);
                                    System.out.println("Ingrese una clave valida para la asignatura a impartir: ");
                                    opasig = sc.nextLine();
                                }while(!hash_asignaturas.containsKey(opasig));
                                
                                lista_grupos.add(Grupo.agregarGrupo(lista_profesores.get(opprof-1), hash_asignaturas.get(opasig)));
                                
                            }else if(Profesor.total_profesores == 0){
                                System.out.print("\nAun no hay profesores registrados!!\n");
                                enterParaContinuar();
                                
                            }else if(Asignatura.total_asignaturas != 0){
                                System.out.print("\nAun no hay asignaturas registrados!!\n");
                                enterParaContinuar();
                                
                            }
                            break;
                        case 4:
                            //Si existen profesores la lista correspondiente, se muestran y se le pide al usuario elegir un profesor para darlo de baja, 
                            //eliminandolo de la lista y reduciendo en 1 el contador de los mismos
                            //Si no hay ni profesores ni asignaturas, se muestan en pantalla los mensajes correspondientes
                            if(Profesor.total_profesores != 0){
                                Profesor.listarProfesores(lista_profesores);
                                System.out.println("Elija al profesor al cual desea dar de baja");
                                opprof = Integer.parseInt(sc.nextLine());

                                while(!(0 <= opprof-1 && opprof-1 < Profesor.total_profesores)){
                                    System.out.print("Elija un profesor por su indice en la lista: ");
                                    opprof = Integer.parseInt(sc.nextLine());
                                }
                                lista_profesores.remove(opprof-1);
                                Profesor.total_profesores--;
                                
                            }else{
                                System.out.print("\nAun no hay profesores registrados!!\n");
                                enterParaContinuar();
                            }
                            
                            break;

                        case 5:
                            System.out.println("Hasta pronto");
                            break;

                        default:
                            System.out.println("Ingresa una opcion valida");
                            break;
                        }
                    } while (op2!=5);
                    break;
                case 3:
                    //Menu de servicios escolares
                    do {
                        System.out.println("Portal del servicio escolar\n1)Mostrar asignaturas\n2)Dar de alta asignatura\n3)Dar de baja asignatura\n4)Agregar un libro\n5)Regresar");
                        op2 = Integer.parseInt(sc.nextLine());
                        switch (op2) {
                            case 1:  
                                //Se mostraran todas las asignaturas, en caso de que no haya ninguna, muestra un mensaje que lo indica
                                if (hash_asignaturas.isEmpty()) {
                                    System.out.println("No se ha creado ninguna asignatura");
                                    break;
                                } else {
                                    Asignatura.printAsignatura(hash_asignaturas);
                                }
                                break;

                            case 2:
                                Asignatura a1 = Asignatura.crearAsignatura();
                                hash_asignaturas.put(a1.getClave(),a1);
                                break;
                            case 3:
                                if (hash_asignaturas.isEmpty()) {
                                    System.out.println("No se ha creado ninguna asignatura");
                                    break;
                                } else {
                                    Asignatura.mostrarAsignatura(hash_asignaturas);
                                }
                                do {
                                    do {
                                        System.out.println("Ingrese la clave de la asignatura.");
                                        s = sc.nextLine();
                                        a = s.length() != 4 ? true:false;
                                    } while (a);
                                } while (!hash_asignaturas.containsKey(s));
                                
                                hash_asignaturas.remove(s);
                                System.out.println("La asignatura ha sido removida");
                                break;

                            case 4:
                                if (hash_asignaturas.isEmpty()) {
                                    System.out.println("No se ha creado ninguna asignatura");
                                    break;
                                } else {
                                    Asignatura.mostrarAsignatura(hash_asignaturas);
                                }
                                do{
                                    do {
                                        System.out.println("Ingrese la clave de la asignatura que desea agregar un libro.");
                                        s = sc.nextLine();
                                        a = s.length() != 4 ? true:false;
                                    } while (a);
                                    
                                }while(!hash_asignaturas.containsKey(s));
                                hash_asignaturas.get(s).agregarLibro();
                                System.out.println("El libro fue agregado");

                                break;
                            case 5:
                                System.out.println("Hasta pronto");
                                break;

                            default:
                            System.out.println("Opcion invalida. Ingresa una opcion valida");
                                break;
                        }
                    } while (op2!=5);
                    break;
                case 4:
                    do {
                        System.out.println("Portal de Grupos, Ingrese la opcion deseada\n1)Mostrar grupos\n2)Eliminar grupos\n3)Salir");
                        op2 = Integer.parseInt(sc.nextLine());
                        switch (op2) {
                            case 1:
                                if (lista_grupos.isEmpty()) {
                                    System.out.println("No se ha creado ninguna asignatura");
                                    break;
                                } else {
                                    Grupo.listarGruposAlumno(lista_grupos);
                                }
                                break;
                            case 2: 
                                if (lista_grupos.isEmpty()) {
                                    System.out.println("No se ha creado ninguna asignatura");
                                    break;
                                } else {
                                    Grupo.listarGruposAlumno(lista_grupos);
                                }
                                
                                break;
                            case 3:
                                System.out.println("Hasta pronto");
                                break;
                        
                            default:
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 5:
                    System.out.println("Hasta pronto");
                    break;
            
                default:
                    System.out.println("Ingresa una opcion valida");
                    break;
            }
        }while(op!=5);
    }
    
    
    
    public static void enterParaContinuar(){
        //Metodo para resaltar operaciones clave y brindar interactividad al usuario
        System.out.println("Presione Enter para continuar...");
        try
        {
            System.in.read();
        }  
        catch(Exception e)
        {}  
    }
}