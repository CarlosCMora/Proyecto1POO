package proyectoadminpoo;

import java.util.ArrayList;
import java.util.Scanner;

public class Profesor{
    public static int total_profesores = 0;
    private String nombre; 
    private String apellido;
    private long num_cedula;
    
    public Profesor(){
        
    }
    
    public Profesor(long num_cedula, String nombre, String apellido){
        //costructor de la clase Profesor
        total_profesores++;
        this. num_cedula = (long)num_cedula;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            return false;
        }
    }

    public String getApellido() {
        return apellido;
    }

    public boolean setApellido(String apellido) {
        if(2<apellido.length() && apellido.length()<25){
            this.apellido = apellido;
            return true;
        }else{
            return false;
        }
    }

    public long getNum_cedula() {
        return num_cedula;
    }

    public boolean setNum_cedula(long num_cedula) {
        if(5<=String.valueOf(num_cedula).length() && String.valueOf(num_cedula).length()<=8){
            this.num_cedula = num_cedula;
            return true;
        }
        return false;
    }
    
    static public Profesor agregarProfesor(){
        //Solicita los datos necesarios para llamar al constructor de la clase Profesor y asi regresar el objeto correspondiente
        Profesor profe_act = new Profesor();
        String nombre, apellido;
        boolean error =false;
        
        long num_cedula;
        System.out.println("Ingrese los datos del profesor "+(Profesor.total_profesores+1));
        Scanner sc = new Scanner(System.in);
        
        do{
            if(error == true) System.out.println("Datos invalidos, intente de nuevo");
            System.out.print("Numero de cedula (entre 5 y 8 digitos): ");
            num_cedula = Long.parseLong(sc.nextLine()); 
            error = true;
        }while(!profe_act.setNum_cedula(num_cedula));
        
        error=false;
        do{
            if(error == true) System.out.println("Datos invalidos, intente de nuevo");
            System.out.print("Nombre: ");
            nombre = sc.nextLine();            
            error = true;
        }while(!profe_act.setNombre(nombre));
                
        error=false;
        do{
            if(error == true) System.out.println("Datos invalidos, intente de nuevo");
            System.out.print("Apellido: ");
            apellido = sc.nextLine();
            error = true;
        }while(!profe_act.setApellido(apellido));
        
        return profe_act;
    }
    
    public void mostrarProfesor(){
        //Muestra los datos del objeto de forma desglosada
        System.out.println("Numero de cedula: "+num_cedula);
        System.out.println("Nombre: "+nombre);
        System.out.println("Apellido: "+apellido);
    }
    
    @Override
    public String toString(){
        //Regresa una String conteniendo los datos del objeto
        return nombre+" "+apellido+"\t\t"+num_cedula;
    }
    
    static void mostrarProfesores(ArrayList<Profesor> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma desglosada
        //Con ayuda del metodo mostrarProfesor()
        for (Profesor prof_act : lista){
            prof_act.mostrarProfesor();
        }
        System.out.println();
    }
     
    static void listarProfesores(ArrayList<Profesor> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma compacta y mostrando un indice al usuario
        //Usa el metodo toString()
        System.out.println("Nombre\t\t\tCedula");
        int i = 0;
        for (Profesor prof_act: lista){
            System.out.println((i+1)+". "+prof_act.toString());
            i++;
        }   
    }
}
