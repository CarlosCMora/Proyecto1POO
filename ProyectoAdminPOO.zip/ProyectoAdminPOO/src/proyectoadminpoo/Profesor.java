package proyectoadminpoo;

import java.util.ArrayList;
import java.util.Scanner;

public class Profesor{
    public static int total_profesores = 0;
    private String nombre; 
    private String apellido;
    private long num_cedula;
    
    public Profesor(long num_cedula, String nombre, String apellido){
        //costructor de la clase Profesor
        total_profesores++;
        this. num_cedula = (long)num_cedula;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            return false;
        }
    }

    public String getApellido() {
        return apellido;
    }

    public boolean setApellido(String apellido) {
        if(2<apellido.length() && apellido.length()<25){
            this.apellido = apellido;
            return true;
        }else{
            return false;
        }
    }

    public long getNum_cedula() {
        return num_cedula;
    }

    public void setNum_cedula(long num_cedula) {
        this.num_cedula = num_cedula;
    }
    
    static public Profesor agregarProfesor(){
        //Solicita los datos necesarios para llamar al constructor de la clase Profesor y asi regresar el objeto correspondiente
        String nombre, apellido;
        long num_cedula;
        System.out.println("Ingrese los datos del profesor "+(Profesor.total_profesores+1));
        Scanner sc = new Scanner(System.in);
        System.out.print("Numero de cedula: ");
        num_cedula = sc.nextLong();
        sc.nextLine();
        System.out.print("Nombre: ");
        nombre = sc.nextLine();
        
        System.out.print("Apellido: ");
        apellido = sc.nextLine();
        
        Profesor profesor_act = new Profesor(num_cedula, nombre, apellido);
        return profesor_act;
    }
    
    public void mostrarProfesor(){
        //Muestra los datos del objeto de forma desglosada
        System.out.println("Numero de cedula: "+num_cedula);
        System.out.println("Nombre: "+nombre);
        System.out.println("Apellido: "+apellido);
    }
    
    @Override
    public String toString(){
        //Regresa una String conteniendo los datos del objeto
        return nombre+" "+apellido+"\t\t"+num_cedula;
    }
    
    static void mostrarProfesores(ArrayList<Profesor> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma desglosada
        //Con ayuda del metodo mostrarProfesor()
        for (Profesor prof_act : lista){
            prof_act.mostrarProfesor();
        }
        System.out.println();
    }
     
    static void listarProfesores(ArrayList<Profesor> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma compacta y mostrando un indice al usuario
        //Usa el metodo toString()
        System.out.println("Nombre\t\t\tCedula");
        int i = 0;
        for (Profesor prof_act: lista){
            System.out.println((i+1)+". "+prof_act.toString());
            i++;
        }   
    }
}
