
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;

public class Profesor extends Escolar{
    static List <Profesor>listProfesores = new ArrayList<Profesor>();
    static int total_profesores = 0;
    
    public Profesor(int num_cuenta, String nombre, String apellidos, Domicilio domicilio){
        this.num_cuenta = num_cuenta;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.domicilio = domicilio;
        total_profesores++;
    }
    
}
