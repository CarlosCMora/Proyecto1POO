
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;

public class Grupo {
    int num_grupo;
    String salon;
    Profesor profesor;
    //hora inicio hora salida
    int horarios[][] = new int[5][2];
    List <Alumno>listAlumnos = new ArrayList<Alumno>();
    
}
