package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Grupo {
    public static int total_grupos = 0;
    private int num_grupo;
    private String salon;
    private Profesor profesor;
    private Asignatura asignatura;
    private List <Alumno>listAlumnos = new ArrayList<Alumno>();
    
    //public Grupo(int num, String saln, Profesor profe, Asignatura asig){
    public Grupo(int num, String saln, Profesor profe){
        num_grupo = num;
        salon = saln;
        profesor = profe;
        //asignatura = asig;
        total_grupos++;
    }

    public int getNum_grupo() {
        return num_grupo;
    }

    public String getSalon() {
        return salon;
    }

    public Profesor getProfesor() {
        return profesor;
    }
    
    public Asignatura getAsignatura(){
        return asignatura;
    }

    public List <Alumno> getListAlumnos() {
        return listAlumnos;
    }

    public void setNum_grupo(int num_grupo) {
        this.num_grupo = num_grupo;
    }

    public void setSalon(String salon) {
        this.salon = salon;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }
    
    public void setAsignatura(Asignatura asignatura){
        this.asignatura = asignatura;
    }

    public void setListAlumnos(List <Alumno> listAlumnos) {
        this.listAlumnos = listAlumnos;
    }
    
    //static public Grupo agregarGrupo(Profesor profe_act, Asignatura asig_act){
    static public Grupo agregarGrupo(Profesor profe_act){
        String saln;
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el salon que le corresponde al grupo: ");
        saln = sc.nextLine();
        
        Grupo g_act= new Grupo(total_grupos+1, saln, profe_act);
        return g_act;
    }
    
}
