package proyectoadminpoo;

public class Libro {
    private String nombre;
    private int edicion;
    private int paginas;
    
    public Libro(String n, int ed, int pags){
        nombre = n;
        edicion = ed;
        paginas = pags;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            return false;
        }
        
    }

    public int getEdicion() {
        return edicion;
    }

    public boolean setEdicion(int edicion) {
        if(0<edicion&&edicion<100){
            this.edicion = edicion;
            return true;
        }else{
            return false;
        } 
    }

    public int getPaginas() {
        return paginas;
    }

    public boolean setPaginas(int paginas) {
        if(0<paginas&&paginas<5001){
            this.paginas = paginas;
            return true;
        }else{
            return false;
        }
        
    }
}
