package proyectoadminpoo;

public class Domicilio {
        private String delegacion;
    private String colonia;
    private String direccion;
    
    public Domicilio(String delegacion, String colonia, String direccion){
        this.delegacion = delegacion;
        this.colonia = colonia;
        this.direccion = direccion;
    }

    public String getDelegacion() {
        return delegacion;
    }

    public boolean setDelegacion(String delegacion) {
        if(2<delegacion.length() && delegacion.length()<25){
            this.delegacion = delegacion;
            return true;
        }else{
            return false;
        }
        
    }

    public String getColonia() {
        return colonia;
    }

    public boolean setColonia(String colonia) {
        if(2<colonia.length() && colonia.length()<25){
            this.colonia = colonia;
            return true;
        }else{
            return false;
        }
        
    }

    public String getDireccion() {
        return direccion;
    }

    public boolean setDireccion(String direccion) {
        if(2<direccion.length() && direccion.length()<25){
            this.direccion = direccion;
            return true;
        }else{
            return false;
        }
        
    }
    
    public void mostrarDomicilio(){
        System.out.println("Domicilio: "+delegacion+", "+colonia+", "+direccion);
    }
}
