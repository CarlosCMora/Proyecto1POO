
package proyectoadminpoo;

public class Domicilio {
    String delegacion; //o municipio a la hora de pedir datos
    String colonia;
    String calle;
    int numero;
}
