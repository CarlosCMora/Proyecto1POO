
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ProyectoAdminPOO{

    public static void main(String[] args) {
        ArrayList <Alumno> lista_alumnos = new ArrayList<>();
        ArrayList <Profesor> lista_profesores = new ArrayList<>();
        ArrayList <Grupo> lista_grupos = new ArrayList<>();
        HashMap<Integer, Asignatura> hash_asignaturas = new HashMap<>();
        //ArrayList<Integer> claves_asignaturas = new ArrayList<>(); 
        /*??? Aqui se guardan las claves respectivas de las asignaturas y se asigna la pareja (clave,Asignatura) y si requerimos 
        recorrer las Asignaturas o pedirle al usuario elegir una, iteramos sobre esta lista para que a su vez muestre el hashmap asignaturas ???? 
        
        */
        int op, op2, opprof, opmat;
        Scanner sc = new Scanner(System.in);
        
        lista_profesores.add(new Profesor(4565478, "Juan", "Perez Sanchez"));
        lista_profesores.add(new Profesor(4645789, "Edgar", "Hernandez Benitez"));
        
        do{
            //Menu general
            
            System.out.println("Bienvenido al sistema de inscripcion\n1)Alumnos\n2)Profesores\n3)Servicio Escolar\n4)Salir");
            op = Integer.parseInt(sc.nextLine());
            switch (op){
                case 1:  
                    do {
                        //Menu para alumnos
                        
                        System.out.println("\t\tPortal del alumno\n1)Mostrar datos\n2)Inscribirse\n3)Darse de baja\n4)Regresar");
                        op2 = Integer.parseInt(sc.nextLine());
                        switch (op2) {
                            case 1:  
                                
                                break;

                            case 2:

                                break;
                            case 3:

                                break;

                            case 4:
                                System.out.println("Hasta pronto");
                                break;

                            default:
                                System.out.println("Ingresa una opcion valida");
                                break;
                        }
                    }while (op2!=4);
                    break;
                
                case 2:
                    //Menu para Profesores
                    
                    do {
                    System.out.println("\t\tPortal del profesor\n1)Mostrar profesores\n2)Registrar profesor\n3)Dar de alta grupo\n4)Darse de baja\n5)Regresar");
                    op2 = Integer.parseInt(sc.nextLine());
                    switch (op2) {
                        case 1:  
                            //Si existen profesores en la lista, se muestran, en caso contrario se muestra un mensaje en pantalla
                            if(Profesor.total_profesores != 0){
                                Profesor.mostrarProfesores(lista_profesores);
                            }else{
                                System.out.print("\nAun no hay profesores registrados!!\n");
                                enterParaContinuar();
                            }
                            break;
                        case 2:
                            //Permite al usuario agregar profesores en la lista correspondiente
                            lista_profesores.add(Profesor.agregarProfesor());
                            System.out.print("\nProfesor agregado correctamente\n");
                            enterParaContinuar();
                            break;
                        case 3:
                            //Si existen profesores y asignaturas en sus listas correspondientes, se muestran y se le pide al usuario asignar un profesor y una asignatura al nuevo grupo 
                            //Si no hay ni profesores ni asignaturas, se muestan en pantalla los mensajes correspondientes
                            //if(Profesor.total_profesores != 0 && Asignatura.total_asignaturas != 0){
                            if(Profesor.total_profesores != 0){
                                Profesor.listarProfesores(lista_profesores);
                                //System.out.println(Profesor.total_profesores+1+". Regresar");
                                System.out.println("Elija al profesor al cual le desea asignar grupo");
                                opprof = Integer.parseInt(sc.nextLine());

                                while(!(0 <= opprof-1 && opprof-1 < Profesor.total_profesores)){
                                    System.out.print("Elija un profesor por su indice en la lista: ");
                                    opprof = Integer.parseInt(sc.nextLine());
                                }
                                //PENDIENTE
                                //Listar asiganturas y que el usuario elija de a que asignatura correspondera el grupo, de igual forma que en la parte superior
                                
                                lista_grupos.add(Grupo.agregarGrupo(lista_profesores.get(opprof-1)));
                                
                            }else{
                                System.out.print("\nAun no hay profesores registrados!!\n");
                                enterParaContinuar();
                            }
                           
                            break;
                        case 4:
                            //Si existen profesores la lista correspondiente, se muestran y se le pide al usuario elegir un profesor para darlo de baja, 
                            //eliminandolo de la lista y reduciendo en 1 el contador de los mismos
                            //Si no hay ni profesores ni asignaturas, se muestan en pantalla los mensajes correspondientes
                            if(Profesor.total_profesores != 0){
                                Profesor.listarProfesores(lista_profesores);
                                System.out.println("Elija al profesor al cual desea dar de baja");
                                opprof = Integer.parseInt(sc.nextLine());

                                while(!(0 <= opprof-1 && opprof-1 < Profesor.total_profesores)){
                                    System.out.print("Elija un profesor por su indice en la lista: ");
                                    opprof = Integer.parseInt(sc.nextLine());
                                }
                               
                                lista_profesores.remove(opprof-1);
                                Profesor.total_profesores--;
                                
                            }else{
                                System.out.print("\nAun no hay profesores registrados!!\n");
                                enterParaContinuar();
                            }
                            
                            break;

                        case 5:
                            System.out.println("Hasta pronto");
                            break;

                        default:
                            System.out.println("Ingresa una opcion valida");
                            break;
                        }
                    } while (op2!=5);
                    break;
                case 3:
                    //Menu de servicios escolares
                    do {
                        System.out.println("Portal del servicio escolar\n1)Mostrar asignaturas\n2)Dar de alta asignatura\n3)Dar de baja asignatura\n4)Regresar");
                        op2 = Integer.parseInt(sc.nextLine());
                        switch (op2) {
                            case 1:  
                                
                                break;

                            case 2:

                                break;
                            case 3:

                                break;

                            case 4:
                                System.out.println("Hasta pronto");
                                break;

                            default:
                                break;
                        }
                    } while (op2!=4);
                    break;
                case 4:
                    System.out.println("Hasta pronto");
                    break;
            
                default:
                    System.out.println("Ingresa una opcion valida");
                    break;
            }
        }while(op!=4);
    }
    
    
    
    public static void enterParaContinuar(){
        //Metodo para resaltar operaciones clave y brindar interactividad al usuario
        System.out.println("Presione Enter para continuar...");
        try
        {
            System.in.read();
        }  
        catch(Exception e)
        {}  
    }
}