package proyectoadminpoo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Alumno{
    static int total_alumnos = 0;
    private long numcuenta;
    private String nombre;
    private String apellido;
    private Domicilio domicilio;
    private HashSet<Libro> listalibros = new HashSet<Libro>();
    private int conteo_libros = 0;
    
    public Alumno(long numcuenta, String nombre, String apellido, Domicilio domicilio){
        total_alumnos++;
        this.numcuenta = (long)numcuenta;
        this.nombre = nombre;
        this.apellido = apellido;
        this.domicilio = domicilio;
    }

    public long getNumcuenta() {
        return numcuenta;
    }

    public boolean setNumcuenta(long numcuenta) {
        if(numcuenta<=0){
            this.numcuenta = numcuenta;
            return true;
        }else{
            return false;
        }    
    }

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            return false;
        }
    }

    public String getApellido() {
        return apellido;
    }

    public boolean setApellido(String apellido) {
        if(2<apellido.length() && apellido.length()<25){
            this.apellido = apellido;
            return true;
        }else{
            return false;
        }
    }
    
    static public Alumno agregarAlumno(){
        String nombre, apellido, delegacion, colonia, direccion;
        long num_cuenta;
        System.out.println("Ingrese los datos del alumno "+(Alumno.total_alumnos+1));
        Scanner sc = new Scanner(System.in);
        System.out.print("Numero de cuenta: ");
        num_cuenta = sc.nextLong();
        sc.nextLine();
        System.out.print("Nombre: ");
        nombre = sc.nextLine();
        System.out.print("Apellido: ");
        apellido = sc.nextLine();
        
        System.out.println("Ingrese la direccion del alumno con numero de cuenta "+num_cuenta);
        System.out.print("Delegacion: ");
        delegacion = sc.nextLine();
        System.out.print("Colonia: ");
        colonia = sc.nextLine();
        System.out.print("Direccion: ");
        direccion = sc.nextLine();
        
        Domicilio domicilio_act = new Domicilio(delegacion,colonia,direccion); 
        
        Alumno alumno_act = new Alumno(num_cuenta, nombre, apellido, domicilio_act);
        return alumno_act;
    }
    
    public void mostrarAlumno(){
        System.out.println("Numero de cuenta: "+numcuenta);
        System.out.println("Nombre: "+nombre);
        System.out.println("Apellido: "+apellido);
        domicilio.mostrarDomicilio();
    }
    
    @Override
    public String toString(){
        //Regresa una String conteniendo los datos del objeto
        return nombre+" "+apellido+"\t\t"+numcuenta;
    }
    
     static void mostrarAlumnos(ArrayList<Alumno> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma desglosada
        //Con ayuda del metodo mostrarProfesor()
        for (Alumno alu_act : lista){
            alu_act.mostrarAlumno();
        }
        System.out.println();
    }
     
    static void listarAlumnos(ArrayList<Alumno> lista){
        //Muestra en pantalla los datos de los objetos Profesor contenidos dentro de un ArrayList de forma compacta y mostrando un indice al usuario
        //Usa el metodo toString()
        System.out.println("Nombre\t\t\tNumero de Cuenta");
        int i = 0;
        for (Alumno alu_act: lista){
            System.out.println((i+1)+". "+alu_act.toString());
            i++;
        }   
    }
    
}
