
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;

public class Alumno extends Escolar {
    static List <Alumno>listAlumnos = new ArrayList<Alumno>();
    static int total_alumnos;
    
    public Alumno(int num_cuenta, String nombre, String apellidos, Domicilio domicilio){
        this.num_cuenta = num_cuenta;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.domicilio = domicilio;
        total_alumnos++;
    }
    
    public void
    
}
