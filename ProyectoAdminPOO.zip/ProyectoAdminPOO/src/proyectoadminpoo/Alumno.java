package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Alumno{
    static List <Alumno>listAlumnos = new ArrayList<Alumno>();
    static int total_alumnos = 0;
    private long numcuenta;
    private String nombre;
    private String apellido;
    private Domicilio domicilio;
    private ArrayList<Libro> listalibros = new ArrayList<Libro>();
    private int conteo_libros = 0;
    
    public Alumno(long numcuenta, String nombre, String apellido, Domicilio domicilio){
        total_alumnos++;
        this.numcuenta = (long)numcuenta;
        this.nombre = nombre;
        this.apellido = apellido;
        this.domicilio = domicilio;
    }

    public long getNumcuenta() {
        return numcuenta;
    }

    public boolean setNumcuenta(long numcuenta) {
        if(numcuenta<=0){
            this.numcuenta = numcuenta;
            return true;
        }else{
            return false;
        }    
    }

    public String getNombre() {
        return nombre;
    }

    public boolean setNombre(String nombre) {
        if(2<nombre.length() && nombre.length()<25){
            this.nombre = nombre;
            return true;
        }else{
            return false;
        }
    }

    public String getApellido() {
        return apellido;
    }

    public boolean setApellido(String apellido) {
        if(2<apellido.length() && apellido.length()<25){
            this.apellido = apellido;
            return true;
        }else{
            return false;
        }
    }
    
    static public Alumno agregarAlumno(){
        String nombre, apellido, delegacion, colonia, direccion;
        long num_cuenta;
        System.out.println("Ingrese los datos del alumno "+(Alumno.total_alumnos+1));
        Scanner sc = new Scanner(System.in);
        System.out.print("Numero de cuenta: ");
        num_cuenta = sc.nextLong();
        sc.nextLine();
        System.out.print("Nombre: ");
        nombre = sc.nextLine();
        
        System.out.print("Apellido: ");
        apellido = sc.nextLine();
        
        System.out.println("Ingrese la direccion del alumno con numero de cuenta "+num_cuenta);
        System.out.print("Delegacion: ");
        delegacion = sc.nextLine();
        System.out.print("Colonia: ");
        colonia = sc.nextLine();
        System.out.print("Direccion: ");
        direccion = sc.nextLine();
        
        Domicilio domicilio_act = new Domicilio(delegacion,colonia,direccion); 
        
        Alumno alumno_act = new Alumno(num_cuenta, nombre, apellido, domicilio_act);
        return alumno_act;
    }
    
    public void mostrarAlumno(){
        System.out.println("Numero de cuenta: "+numcuenta);
        System.out.println("Nombre: "+nombre);
        System.out.println("Apellido: "+apellido);
        domicilio.mostrarDomicilio();
    }
    
     /*public Alumno(int num_cuenta, String nombre, String apellidos, Domicilio domicilio){
        this.num_cuenta = num_cuenta;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.domicilio = domicilio;
        total_alumnos++;
    }
    
    public void*/
    
}
