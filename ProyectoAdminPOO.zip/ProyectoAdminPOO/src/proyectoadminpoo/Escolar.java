
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;

public class Escolar {
    int num_cuenta;
    String nombre;
    String apellidos;
    Domicilio domicilio;
    List <Grupo>listGrupo = new ArrayList<Grupo>();
    
    public void printDatos(){
        System.out.println("Numero de cuenta: "+num_cuenta);
        System.out.println("Nombre: "+nombre+" "+apellidos);
        domicilio.printDomicilio();       
    }
    
    public void inscribirGrupo(){
        
    }
    
    public void baja(){
        
    }
    
}
