
package proyectoadminpoo;

import java.util.ArrayList;
import java.util.List;

public class Asignatura {
    int clave;
    String nombre;
    int creditos;
    //Tabla HASH
    List <Grupo>listGrupos = new ArrayList<Grupo>();
    static int total_asignaturas;
    
    public Asignatura(){
        total_asignaturas++;
    }
    
    
}
