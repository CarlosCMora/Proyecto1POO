package proyectoadminpoo;

public class Asignatura {
    static int total_asignaturas = 0;
    private int clave;
    private String nombre;
    private int creditos;
    
    public Asignatura(){
        total_asignaturas++;
    }

    public int getClave() {
        return clave;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }
    
    
}
